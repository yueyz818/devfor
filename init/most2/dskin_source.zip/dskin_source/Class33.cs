﻿using DSkin.Html.Core.Dom;
using DSkin.Html.Core.Entities;
using System;

internal sealed class Class33
{
    private readonly CssBlock cssBlock_0;
    private readonly CssBox cssBox_0;

    public Class33(CssBox cssBox_1, CssBlock cssBlock_1)
    {
        this.cssBox_0 = cssBox_1;
        this.cssBlock_0 = cssBlock_1;
    }

    public CssBox method_0()
    {
        return this.cssBox_0;
    }

    public CssBlock method_1()
    {
        return this.cssBlock_0;
    }
}

