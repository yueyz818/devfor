﻿using System;

internal static class Class0
{
}

