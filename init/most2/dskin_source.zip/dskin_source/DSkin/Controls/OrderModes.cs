﻿namespace DSkin.Controls
{
    using System;

    public enum OrderModes
    {
        None,
        Descending,
        Ascending
    }
}

