﻿namespace DSkin.Controls
{
    using System;

    public enum DragBarPositions
    {
        LeftTop,
        LeftBottom,
        RightTop,
        RightBottom,
        Top,
        Bottom,
        Left,
        Right
    }
}

