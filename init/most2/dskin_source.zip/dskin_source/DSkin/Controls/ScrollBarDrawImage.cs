﻿namespace DSkin.Controls
{
    using System;
    using System.Drawing;

    public class ScrollBarDrawImage
    {
        public static Bitmap Fader = Resources.smethod_19();
        public static Bitmap ScrollHorzArrow = Resources.smethod_37();
        public static Bitmap ScrollHorzShaft = Resources.smethod_38();
        public static Bitmap ScrollHorzThumb = Resources.smethod_39();
        public static Bitmap ScrollVertArrow = Resources.smethod_40();
        public static Bitmap ScrollVertShaft = Resources.smethod_42();
        public static Bitmap ScrollVertThumb = Resources.smethod_43();
    }
}

