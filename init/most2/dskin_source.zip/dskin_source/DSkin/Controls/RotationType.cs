﻿namespace DSkin.Controls
{
    using System;

    public enum RotationType
    {
        Clockwise = 1,
        CounterClockwise = -1
    }
}

