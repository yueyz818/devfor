﻿namespace DSkin.Controls
{
    using DSkin.Common;

    public interface ITreeViewNode
    {
        Collection<DSkinTreeViewNode> Nodes { get; }
    }
}

