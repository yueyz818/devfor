﻿namespace DSkin.Controls
{
    using System;

    public enum ButtonStatus
    {
        LeftDown,
        LeftUp,
        RightDown,
        RightUp,
        None
    }
}

