﻿namespace DSkin.Controls
{
    using System;

    public enum GridLineShowModes
    {
        None,
        All,
        Horizontal,
        Vertical
    }
}

