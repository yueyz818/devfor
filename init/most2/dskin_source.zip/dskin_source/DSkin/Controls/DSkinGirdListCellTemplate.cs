﻿namespace DSkin.Controls
{
    public class DSkinGirdListCellTemplate : DSkinGridListCellTemplate
    {
    }
}

