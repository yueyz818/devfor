﻿namespace DSkin.Controls
{
    using System;

    public enum ColorSelectMode
    {
        Default,
        Hue,
        Sat,
        Lum
    }
}

