﻿namespace DSkin.Controls
{
    using System;

    public enum ControlType
    {
        DuiTextBox,
        DuiLabel,
        DuiButton,
        DuiPictureBox,
        DuiCheckBox,
        DuiRadioButton,
        DuiComboBox
    }
}

