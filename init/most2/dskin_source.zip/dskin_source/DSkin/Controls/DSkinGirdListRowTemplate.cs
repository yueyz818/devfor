﻿namespace DSkin.Controls
{
    public class DSkinGirdListRowTemplate : DSkinGridListRowTemplate
    {
    }
}

