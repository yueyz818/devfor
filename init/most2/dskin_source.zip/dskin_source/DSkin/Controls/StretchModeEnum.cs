﻿namespace DSkin.Controls
{
    using System;

    public enum StretchModeEnum
    {
        STRETCH_ANDSCANS = 1,
        STRETCH_DELETESCANS = 3,
        STRETCH_HALFTONE = 4,
        STRETCH_ORSCANS = 2
    }
}

