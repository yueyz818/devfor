﻿namespace DSkin.Controls
{
    using System;

    public enum CollapsePanel
    {
        None,
        Panel1,
        Panel2
    }
}

