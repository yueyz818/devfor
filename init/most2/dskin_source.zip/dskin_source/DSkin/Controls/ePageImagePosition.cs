﻿namespace DSkin.Controls
{
    using System;

    public enum ePageImagePosition
    {
        Left,
        Right,
        Top,
        Bottom
    }
}

