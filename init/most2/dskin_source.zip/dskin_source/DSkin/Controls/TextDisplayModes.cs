﻿namespace DSkin.Controls
{
    using System;

    [Flags]
    public enum TextDisplayModes
    {
        None,
        Percentage,
        Text,
        Both
    }
}

