﻿namespace DSkin.Controls
{
    using System;

    public enum SelectionModes
    {
        None,
        Radio,
        MultipleSelection
    }
}

