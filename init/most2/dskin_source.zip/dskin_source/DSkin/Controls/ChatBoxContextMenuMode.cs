﻿namespace DSkin.Controls
{
    using System;

    public enum ChatBoxContextMenuMode
    {
        None,
        ForInput,
        ForOutput
    }
}

