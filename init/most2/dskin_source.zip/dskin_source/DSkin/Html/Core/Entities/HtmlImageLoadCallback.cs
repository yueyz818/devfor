﻿namespace DSkin.Html.Core.Entities
{
    using DSkin.Html.Adapters.Entities;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void HtmlImageLoadCallback(string path, object image, RRect imageRectangle);
}

