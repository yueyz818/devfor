﻿namespace DSkin.Html.Core.Entities
{
    using System;

    public enum HtmlGenerationStyle
    {
        None,
        Inline,
        InHeader
    }
}

