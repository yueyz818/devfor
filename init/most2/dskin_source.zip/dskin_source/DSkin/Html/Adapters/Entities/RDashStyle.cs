﻿namespace DSkin.Html.Adapters.Entities
{
    using System;

    public enum RDashStyle
    {
        Solid,
        Dash,
        Dot,
        DashDot,
        DashDotDot,
        Custom
    }
}

