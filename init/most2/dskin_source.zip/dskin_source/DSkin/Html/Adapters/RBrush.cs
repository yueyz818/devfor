﻿namespace DSkin.Html.Adapters
{
    using System;

    public abstract class RBrush : IDisposable
    {
        protected RBrush()
        {
        }

        public abstract void Dispose();
    }
}

