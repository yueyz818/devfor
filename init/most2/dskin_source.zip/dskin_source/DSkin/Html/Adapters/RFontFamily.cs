﻿namespace DSkin.Html.Adapters
{
    using System;

    public abstract class RFontFamily
    {
        protected RFontFamily()
        {
        }

        public abstract string Name { get; }
    }
}

