﻿namespace DSkin.OLE
{
    using System;

    public enum GETOBJECTOPTIONS
    {
        REO_GETOBJ_ALL_INTERFACES = 7,
        REO_GETOBJ_NO_INTERFACES = 0,
        REO_GETOBJ_POLEOBJ = 1,
        REO_GETOBJ_POLESITE = 4,
        REO_GETOBJ_PSTG = 2
    }
}

