﻿namespace DSkin.OLE
{
    using System;

    public enum GETCLIPBOARDDATAFLAGS
    {
        RECO_PASTE,
        RECO_DROP,
        RECO_COPY,
        RECO_CUT,
        RECO_DRAG
    }
}

