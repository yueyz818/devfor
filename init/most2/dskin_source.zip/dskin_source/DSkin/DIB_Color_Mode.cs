﻿namespace DSkin
{
    using System;

    public enum DIB_Color_Mode : uint
    {
        DIB_PAL_COLORS = 1,
        DIB_RGB_COLORS = 0
    }
}

