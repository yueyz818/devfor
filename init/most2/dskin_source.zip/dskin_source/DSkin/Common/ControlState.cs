﻿namespace DSkin.Common
{
    using System;

    public enum ControlState
    {
        Normal,
        Hover,
        Pressed,
        Focused
    }
}

