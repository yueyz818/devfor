﻿namespace DSkin.Common
{
    using System;

    public static class GeneralUtil
    {
    }
}

