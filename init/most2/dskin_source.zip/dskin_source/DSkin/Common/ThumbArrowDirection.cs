﻿namespace DSkin.Common
{
    using System;

    public enum ThumbArrowDirection
    {
        None,
        Left,
        Right,
        Up,
        Down,
        LeftRight,
        UpDown
    }
}

