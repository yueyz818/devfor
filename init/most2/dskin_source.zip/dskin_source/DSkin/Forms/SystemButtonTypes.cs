﻿namespace DSkin.Forms
{
    using System;

    public enum SystemButtonTypes
    {
        Close,
        Minimized,
        Maximized,
        Normal,
        None
    }
}

