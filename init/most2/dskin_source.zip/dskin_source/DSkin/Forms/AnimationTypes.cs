﻿namespace DSkin.Forms
{
    using System;

    public enum AnimationTypes
    {
        ZoomEffect,
        GradualCurtainEffect,
        FadeinFadeoutEffect,
        RotateZoomEffect,
        const_4,
        Custom
    }
}

