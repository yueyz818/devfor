﻿namespace DSkin.Forms
{
    using System;

    public enum MoveModes
    {
        None,
        Title,
        Whole
    }
}

