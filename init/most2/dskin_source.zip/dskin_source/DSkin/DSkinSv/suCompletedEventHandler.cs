﻿namespace DSkin.DSkinSv
{
    using System;
    using System.CodeDom.Compiler;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Web.Services", "4.0.30319.19408")]
    public delegate void suCompletedEventHandler(object sender, suCompletedEventArgs e);
}

