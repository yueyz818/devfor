﻿namespace DSkin.DirectUI
{
    using System;

    public enum TextEffects
    {
        None,
        Forme,
        Shadow,
        Glow,
        Path
    }
}

