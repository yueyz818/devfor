﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeSettingMask
    {
        WKE_SETTING_PROXY = 1
    }
}

