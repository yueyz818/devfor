﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate long wkeJSCallAsFunctionCallback(IntPtr es, long @object, ref long args, int argCount);
}

