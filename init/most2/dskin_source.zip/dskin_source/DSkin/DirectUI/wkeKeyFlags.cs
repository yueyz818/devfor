﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeKeyFlags
    {
        WKE_EXTENDED = 0x100,
        WKE_REPEAT = 0x4000
    }
}

