﻿namespace DSkin.DirectUI
{
    using System;

    public enum BorderTypes
    {
        Solid,
        Dash,
        DashDot,
        DashDotDot,
        Dot
    }
}

