﻿namespace DSkin.DirectUI
{
    using System;

    public enum GraphicsTypes
    {
        Point,
        Line,
        Rectangle,
        Ellipse,
        Pie,
        Arc,
        Bezier,
        Polygon
    }
}

