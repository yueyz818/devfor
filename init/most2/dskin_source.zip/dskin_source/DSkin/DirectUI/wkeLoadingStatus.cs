﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeLoadingStatus
    {
        WKE_STATE_UNINITIALIZED,
        WKE_STATE_LOADING,
        WKE_STATE_LOADING_SUCCEED,
        WKE_STATE_LOADING_FAILED,
        WKE_STATE_DOCUMENT_READY
    }
}

