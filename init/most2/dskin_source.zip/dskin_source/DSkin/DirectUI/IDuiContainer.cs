﻿namespace DSkin.DirectUI
{
    public interface IDuiContainer
    {
        DuiBaseControl InnerDuiControl { get; }
    }
}

