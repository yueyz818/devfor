﻿namespace DSkin.DirectUI
{
    using System;

    public class GAttribute0 : Attribute
    {
    }
}

