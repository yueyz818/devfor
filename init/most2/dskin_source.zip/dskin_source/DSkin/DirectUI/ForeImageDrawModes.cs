﻿namespace DSkin.DirectUI
{
    using System;

    public enum ForeImageDrawModes
    {
        Stretch,
        Sudoku,
        Normal,
        Tile,
        Translate
    }
}

