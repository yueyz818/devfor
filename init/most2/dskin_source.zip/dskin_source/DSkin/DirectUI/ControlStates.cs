﻿namespace DSkin.DirectUI
{
    using System;

    public enum ControlStates
    {
        Normal,
        Hover,
        Pressed,
        Focused
    }
}

