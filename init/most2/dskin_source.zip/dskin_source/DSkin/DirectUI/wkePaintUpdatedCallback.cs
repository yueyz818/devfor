﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void wkePaintUpdatedCallback(IntPtr webView, IntPtr param, IntPtr hdc, int x, int y, int cx, int cy);
}

