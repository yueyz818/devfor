﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void wkeJSFinalizeCallback(ref wkeJSData data);
}

