﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeMouseFlags
    {
        WKE_CONTROL = 8,
        WKE_LBUTTON = 1,
        WKE_MBUTTON = 0x10,
        WKE_RBUTTON = 2,
        WKE_SHIFT = 4
    }
}

