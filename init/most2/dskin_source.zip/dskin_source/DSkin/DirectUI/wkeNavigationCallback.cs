﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate wkeNavigationAction wkeNavigationCallback(IntPtr webView, DSkin.DirectUI.wkeNavigationType navigationType, IntPtr url);
}

