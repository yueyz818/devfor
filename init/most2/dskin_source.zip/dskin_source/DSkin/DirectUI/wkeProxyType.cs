﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeProxyType
    {
        WKE_PROXY_NONE,
        WKE_PROXY_HTTP,
        WKE_PROXY_SOCKS4,
        WKE_PROXY_SOCKS4A,
        WKE_PROXY_SOCKS5,
        WKE_PROXY_SOCKS5HOSTNAME
    }
}

