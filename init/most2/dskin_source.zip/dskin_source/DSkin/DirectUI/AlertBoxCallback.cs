﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AlertBoxCallback(IntPtr webView, IntPtr msg);
}

