﻿namespace DSkin.DirectUI
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void TitleChangedCallback(IntPtr webView, IntPtr title);
}

