﻿namespace DSkin.DirectUI
{
    using System;

    public enum wkeJSType
    {
        WKE_JSTYPE_NUMBER,
        WKE_JSTYPE_STRING,
        WKE_JSTYPE_BOOLEAN,
        WKE_JSTYPE_OBJECT,
        WKE_JSTYPE_FUNCTION,
        WKE_JSTYPE_UNDEFINED
    }
}

