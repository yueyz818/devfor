﻿namespace DSkin.Imaging
{
    using System;

    public enum GrayscaleStyle
    {
        BT907,
        RMY,
        Y
    }
}

