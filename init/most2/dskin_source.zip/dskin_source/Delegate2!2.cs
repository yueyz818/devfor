﻿using System;
using System.Runtime.CompilerServices;

internal delegate void Delegate2<in RtEkFFWoSNdHLngscDr, in bt5AsTWRRJ8yxUTaSsQ>(RtEkFFWoSNdHLngscDr arg1, bt5AsTWRRJ8yxUTaSsQ arg2);

