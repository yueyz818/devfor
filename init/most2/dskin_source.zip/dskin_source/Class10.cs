﻿using System;

internal class Class10
{
}

