﻿using System;
using System.Runtime.CompilerServices;

internal delegate void Delegate1<in z8dVWmWFVxi9BclQpM4>(z8dVWmWFVxi9BclQpM4 obj);

