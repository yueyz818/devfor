﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

internal class Class20
{
    [CompilerGenerated]
    private List<Class21> list_0;
    [CompilerGenerated]
    private object object_0;

    public Class20()
    {
        this.method_3(new List<Class21>());
    }

    [CompilerGenerated]
    public object method_0()
    {
        return this.object_0;
    }

    [CompilerGenerated]
    public void method_1(object object_1)
    {
        this.object_0 = object_1;
    }

    [CompilerGenerated]
    public List<Class21> method_2()
    {
        return this.list_0;
    }

    [CompilerGenerated]
    public void method_3(List<Class21> list_1)
    {
        this.list_0 = list_1;
    }
}

