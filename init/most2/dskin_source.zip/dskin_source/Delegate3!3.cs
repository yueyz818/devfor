﻿using System;
using System.Runtime.CompilerServices;

internal delegate void Delegate3<in d8prkxWEOjxiNCBKOpy, in R5ugAQWqrDYkMt6F3B7, in zUKPjGW8HYI83iVwSuY>(d8prkxWEOjxiNCBKOpy arg1, R5ugAQWqrDYkMt6F3B7 arg2, zUKPjGW8HYI83iVwSuY arg3);

